/* tslint:disable */
require("./UploadAvatar.module.css");
const styles = {
  'text-size': 'text-size_44369ed2',
  note: 'note_44369ed2'
};

export default styles;
/* tslint:enable */